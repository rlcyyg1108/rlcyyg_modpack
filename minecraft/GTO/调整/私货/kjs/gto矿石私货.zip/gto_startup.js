StartupEvents.registry("item", e => {
    e.create("gto:overworld_fragment")
        .displayName("主世界碎片")
        .maxStackSize(64);
    e.create("gto:steel_drill").displayName("钢钻头").maxStackSize(64);
    e.create("gto:titanium_drill").displayName("钛钻头").maxStackSize(64);
    e.create("gto:tungsten_drill").displayName("钨钻头").maxStackSize(64);
});

StartupEvents.registry("block", e => {
    e.create("gto:fragment_world_harvester")
        .displayName("碎片世界采集器")
        .hardness(3)
        .resistance(10)
        .material("stone")
        .requiresTool(true);
});

ItemEvents.modification(event => {
    event.modify("gto:steel_drill", i => i.maxStackSize = 64);
    event.modify("gto:titanium_drill", i => i.maxStackSize = 64);
    event.modify("gto:tungsten_drill", i => i.maxStackSize = 64);
});