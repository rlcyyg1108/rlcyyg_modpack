ServerEvents.recipes(event => {
    event.shapeless("gto:fragment_world_harvester", ["minecraft:crafting_table"]);
});

// 产出数量（改这个数字就能调整所有矿石产出数量）
const OUTPUT_COUNT = 2;

// 矿石（想要什么矿石在这底下改）
const ALL_ORES = [
    "minecraft:iron_ore",
    "minecraft:copper_ore",
    "minecraft:gold_ore",
    "minecraft:redstone_ore",
    "minecraft:diamond_ore",
    "minecraft:emerald_ore",
    "minecraft:lapis_ore",
    "minecraft:coal_ore",
    "minecraft:amethyst_block",
    "minecraft:nether_quartz_ore",
    "minecraft:ancient_debris",
    "minecraft:nether_gold_ore",
    "minecraft:end_stone",
    "minecraft:chorus_plant",

    "gtocore:living_rock_perditio_crystal_ore",
    "gtocore:living_rock_gnome_crystal_ore",
    "gtocore:living_rock_sylph_crystal_ore",
    "gtocore:living_rock_undine_crystal_ore",
    "gtocore:living_rock_salamander_crystal_ore",
    "gtocore:living_rock_nether_ember_ore",
    "gtocore:living_rock_mana_diamond_ore",
    "gtocore:living_rock_dragonstone_ore",
    "gtocore:living_rock_remnant_spirit_stone_ore",
    "gtocore:living_rock_soul_jade_crystal_ore",
    "gtocore:living_rock_star_blood_crystal_ore",
    "gtocore:living_rock_origin_core_crystal_ore",
    "gtocore:living_rock_gaia_core_ore",
    "gtocore:living_rock_elementium_ore",
    "gtocore:living_rock_manasteel_ore",
    "gtocore:living_rock_thaumium_ore",
    "gtocore:living_rock_infused_gold_ore",
    "gtocore:living_rock_sourcegem_ore",

    "gtocore:moon_stone_aluminium_ore",
    "gtocore:moon_stone_neodymium_ore",
    "gtocore:moon_stone_monazite_ore",
    "gtocore:moon_stone_ilmenite_ore",
    "gtocore:moon_stone_bauxite_ore",
    "gtocore:moon_stone_uraninite_ore",
    "gtocore:moon_stone_bastnasite_ore",
    "gtocore:moon_stone_pitchblende_ore",

    "gtocore:mars_stone_palladium_ore",
    "gtocore:mars_stone_platinum_ore",
    "gtocore:mars_stone_cooperite_ore",

    "minecraft:nether_star",
    "minecraft:ender_pearl"
];

BlockEvents.rightClicked("gto:fragment_world_harvester", function(event) {
    if (event.level.isClientSide()) {
        return;
    }

    var player = event.player;
    if (!player) {
        return;
    }

    var hasFragment = false;
    for (var i = 0; i < player.inventory.getContainerSize(); i++) {
        var stack = player.inventory.getItem(i);
        if (stack.getItem().getId() === "gto:overworld_fragment") {
            hasFragment = true;
            break;
        }
    }
    if (!hasFragment) {
        player.tell("§c缺少主世界碎片，无法采集！");
        return;
    }

    var hasDrill = false;
    var drills = ["gto:steel_drill", "gto:titanium_drill", "gto:tungsten_drill"];
    for (var i = 0; i < player.inventory.getContainerSize(); i++) {
        var stack = player.inventory.getItem(i);
        var itemId = stack.getItem().getId();
        if (drills.includes(itemId)) {
            hasDrill = true;
            break;
        }
    }
    if (!hasDrill) {
        player.tell("§c缺少钻头（钢/钛/钨均可），无法采集！");
        return;
    }

    for (var i = 0; i < ALL_ORES.length; i++) {
        var oreId = ALL_ORES[i];
        player.give(oreId + " " + OUTPUT_COUNT);
    }

    player.tell("§a成功获得全矿石！");
});