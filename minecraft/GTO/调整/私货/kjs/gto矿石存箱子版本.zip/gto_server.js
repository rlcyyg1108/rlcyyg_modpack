ServerEvents.recipes(e => {
    e.shapeless("gto:fragment_harvester", ["minecraft:crafting_table"]);
});

// 每次叠加数量（自己改）
var ADD_COUNT = 2;
// 矿石列表（自己加）
var ALL_ORES = [
    "minecraft:iron_ore",
    "minecraft:copper_ore",
    "minecraft:gold_ore",
    "minecraft:redstone_ore",
    "minecraft:diamond_ore",
    "minecraft:emerald_ore",
    "minecraft:lapis_ore",
    "minecraft:coal_ore",
    "minecraft:amethyst_block",
    "minecraft:nether_quartz_ore",
    "minecraft:ancient_debris",
    "minecraft:nether_gold_ore",
    "gtocore:living_rock_perditio_crystal_ore",
    "gtocore:living_rock_gnome_crystal_ore",
    "gtocore:living_rock_sylph_crystal_ore",
    "gtocore:living_rock_undine_crystal_ore",
    "gtocore:living_rock_salamander_crystal_ore",
    "gtocore:living_rock_nether_ember_ore",
    "gtocore:living_rock_mana_diamond_ore",
    "gtocore:living_rock_dragonstone_ore",
    "gtocore:living_rock_remnant_spirit_stone_ore",
    "gtocore:living_rock_soul_jade_crystal_ore",
    "gtocore:living_rock_star_blood_crystal_ore",
    "gtocore:living_rock_origin_core_crystal_ore",
    "gtocore:living_rock_gaia_core_ore",
    "gtocore:living_rock_elementium_ore",
    "gtocore:living_rock_manasteel_ore",
    "gtocore:living_rock_thaumium_ore",
    "gtocore:living_rock_infused_gold_ore",
    "gtocore:living_rock_sourcegem_ore",
    "gtocore:moon_stone_aluminium_ore",
    "gtocore:moon_stone_neodymium_ore",
    "gtocore:moon_stone_monazite_ore",
    "gtocore:moon_stone_ilmenite_ore",
    "gtocore:moon_stone_bauxite_ore",
    "gtocore:moon_stone_uraninite_ore",
    "gtocore:moon_stone_bastnasite_ore",
    "gtocore:moon_stone_pitchblende_ore",
    "gtocore:mars_stone_palladium_ore",
    "gtocore:mars_stone_platinum_ore",
    "gtocore:mars_stone_cooperite_ore",
    "minecraft:nether_star",
    "minecraft:ender_pearl"
];

var playerCooldown = new Map();
var COOLDOWN_TICK = 40;
var DETECT_DIRECTIONS = [
    { x: 0, y: -1, z: 0, name: "正下方" },
    { x: 0, y: 0, z: -1, name: "北方" },
    { x: 0, y: 0, z: 1, name: "南方" },
    { x: -1, y: 0, z: 0, name: "西方" },
    { x: 1, y: 0, z: 0, name: "东方" },
    { x: 0, y: 1, z: 0, name: "上方" }
];

BlockEvents.rightClicked('gto:fragment_harvester', event => {
    if (event.level.isClientSide() || event.hand !== "MAIN_HAND") return;
    
    var player = event.player;
    var level = event.level;
    var playerUUID = player.uuid.toString();
    var currentTick = level.gameTime;
    var blockPos = event.block.pos;
    var x = blockPos.getX();
    var y = blockPos.getY();
    var z = blockPos.getZ();
    var targetChestPos = null;
    var targetChestBlock = null;
    var isChest = false;
    var chestDirectionName = "";
    var dirIndex;
    var dir;
    var chestTE;
    var maxSlot;
    var slotIndex;
    var targetItemId;
    var currentStack;
    var newCount;

    if (playerCooldown.has(playerUUID) && currentTick - playerCooldown.get(playerUUID) < COOLDOWN_TICK) {
        return;
    }
    playerCooldown.set(playerUUID, currentTick);

    for (dirIndex = 0; dirIndex < DETECT_DIRECTIONS.length; dirIndex++) {
        dir = DETECT_DIRECTIONS[dirIndex];
        targetChestPos = new BlockPos(x + dir.x, y + dir.y, z + dir.z);
        targetChestBlock = level.getBlock(targetChestPos);
        isChest = targetChestBlock.getId().toString().includes("chest");
        
        if (isChest) {
            chestDirectionName = dir.name;
            break;
        }
    }

    if (!isChest) {
        for (slotIndex = 0; slotIndex < ALL_ORES.length; slotIndex++) {
            player.give(Item.of(ALL_ORES[slotIndex], ADD_COUNT));
        }
        player.tell("§a✅ 未检测到周围箱子，矿石已放入背包！");
        return;
    }

    try {
        chestTE = level.getBlockEntity(targetChestPos);
        if (!chestTE) throw new Error("未获取到箱子实体");
        maxSlot = chestTE.getContainerSize();

        for (slotIndex = 0; slotIndex < ALL_ORES.length && slotIndex < maxSlot; slotIndex++) {
            targetItemId = ALL_ORES[slotIndex];
            currentStack = chestTE.getStackInSlot(slotIndex);

            if (!currentStack.isEmpty() && currentStack.getId() === targetItemId) {
                newCount = currentStack.getCount() + ADD_COUNT;
                chestTE.setStackInSlot(slotIndex, Item.of(targetItemId, newCount));
            } else {
                chestTE.setStackInSlot(slotIndex, Item.of(targetItemId, ADD_COUNT));
            }
        }

        chestTE.setChanged();
        player.tell("§a✅ 矿石已叠加存入" + chestDirectionName + "的箱子！每种+" + ADD_COUNT);
    } catch (error) {
        for (slotIndex = 0; slotIndex < ALL_ORES.length; slotIndex++) {
            player.give(Item.of(ALL_ORES[slotIndex], ADD_COUNT));
        }
        player.tell("§e⚠️ 存箱失败，矿石已自动放入背包！");
    }
});