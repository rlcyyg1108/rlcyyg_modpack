// ==========================================================
// GTO Odyssey - Client 客户端脚本
// 存放路径: kubejs/client_scripts/
// ==========================================================

const CLIENT_CONFIG = {
    modId: "gto",
    enableEMI: true
};

// ===================== 【EMI 支持】 =====================

if (CLIENT_CONFIG.enableEMI) {
    // 注意：具体的EMI注册方法取决于你安装的EMI版本和KubeJS集成
    // 这里提供一个通用的容错框架
    try {
        // 如果你的EMI版本支持旧版API，取消下面注释
        /*
        ClientEvents.emiRegistry(event => {
            console.log("§a[GTO] EMI 分类注册完成");
        });
        */
       
        // 对于新版，通常物品会自动出现在搜索中，
        // 因为我们已经在startup脚本里添加了创造模式标签页
        console.log("§a[GTO] 客户端加载完成 (EMI模式)");
       
    } catch (e) {
        console.warn("§7[GTO] EMI 集成未启用 (这通常不是错误)");
    }
}