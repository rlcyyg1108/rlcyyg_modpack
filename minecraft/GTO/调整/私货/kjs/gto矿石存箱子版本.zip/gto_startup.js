// 仅注册必要物品
StartupEvents.registry("item", e => {
    e.create("gto:overworld_fragment").displayName("主世界碎片");
    e.create("gto:steel_drill").displayName("钢钻头");
});
StartupEvents.registry("block", e => {
    e.create("gto:fragment_harvester").displayName("碎片采集器").hardness(3);
});