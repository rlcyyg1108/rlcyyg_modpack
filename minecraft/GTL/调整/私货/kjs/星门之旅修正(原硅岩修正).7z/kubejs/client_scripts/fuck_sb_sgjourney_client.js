const modId = 'sgjourney';
const keywords = ['stargate', 'dhd', 'chamber', 'transport_ring', 'crystal_base'];
// 物品部分
JEIEvents.hideItems(event => {
  let itemsToHide = [];
  Ingredient.all.itemIds.forEach(itemId => {
    if (itemId.startsWith(`${modId}:`)) {
      let containsAnyKeyword = keywords.some(keyword => 
        itemId.toLowerCase().includes(keyword)
      );
      if (!containsAnyKeyword) {
        itemsToHide.push(itemId);
      }
    }
  });
  itemsToHide.push('sgjourney:advanced_crystal_base');
  itemsToHide.push('sgjourney:stargate_shielding_ring');
  itemsToHide=Array.from(new Set(itemsToHide))
  console.log(`[星门之旅修正] 匹配到 ${itemsToHide.length} 个不包含${keywords}关键词的物品:`);
  itemsToHide.push('expatternprovider:silicon_block')
  console.log(`[星门之旅修正] 干掉了EAE的硅块，顺手的事`);
  console.log(itemsToHide);
  
  itemsToHide.forEach(itemId => {
    event.hide(itemId);
  });
  
  console.log(`[星门之旅修正] 已隐藏 ${itemsToHide.length} 个物品`);
});
//流体部分
JEIEvents.hideFluids(event => {
  event.hide('sgjourney:liquid_naquadah_ban');
  event.hide('sgjourney:heavy_liquid_naquadah_ban');
  console.log(`[星门之旅修正] 已隐藏 ${modId} 的流体`);
});