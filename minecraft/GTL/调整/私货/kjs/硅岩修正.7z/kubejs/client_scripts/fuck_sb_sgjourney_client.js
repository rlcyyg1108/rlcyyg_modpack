//干掉JEI中星门之旅的所有带有硅岩关键词的物品显示
JEIEvents.hideItems(event => {
  const modId = 'sgjourney';
  const keyword = 'naquadah';
  let matchingItems = [];
  
  Ingredient.all.itemIds.forEach(itemId => {
    if (itemId.startsWith(`${modId}:`) && 
        itemId.toLowerCase().includes(keyword)) {
      matchingItems.push(itemId);
    }
  });
  console.log(`[硅岩修正] 找到 ${matchingItems.length} 个匹配 "${keyword}" 的物品:`);
  matchingItems.forEach((item, index) => {
    console.log(`  ${index + 1}. ${item}`);
  });
  matchingItems.forEach(itemId => {
    event.hide(itemId);
  });
  console.log(`[硅岩修正] 已隐藏 ${matchingItems.length} 个物品`);
  
});