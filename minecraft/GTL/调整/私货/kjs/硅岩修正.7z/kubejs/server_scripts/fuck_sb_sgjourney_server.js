//干掉星门之旅的硅岩、硅岩合金、硅岩杆的所有标签以移除其所有配方
ServerEvents.tags('item', event => {
    event.removeAllTagsFrom('sgjourney:naquadah_rod')
    event.removeAllTagsFrom('sgjourney:naquadah_alloy')
    event.removeAllTagsFrom('sgjourney:naquadah')
})