StartupEvents.registry('item', event =>{
    const tools = [{tool:'crowbar',name:'撬棍',tag:'crowbars'},
                    {tool:'hammer',name:'锻造锤',tag:'hammers'},
                    {tool:'mallet',name:'软锤',tag:'mallets'},
                    {tool:'saw',name:'锯',tag:'saws'},
                    {tool:'screwdriver',name:'螺丝刀',tag:'screwdrivers'},
                    {tool:'wire_cutter',name:'剪线钳',tag:'wire_cutters'},
                    {tool:'wrench',name:'扳手',tag:'wrenches'},
                    {tool:'file',name:'锉',tag:'files'}]
    tools.forEach(i=>{
        event.create('fragile_tool:fragile_'+i.tool)
        .texture('fragile_tool:item/fragile_'+i.tool)
        .tag("forge:tools/"+i.tag)
        .displayName('脆弱的'+i.name)
    })
})
StartupEvents.modifyCreativeTab("kubejs:tab", event => {
    const packed_infinity_cell_1 = (cellname,type,list)=>{
    const list_length = list.length
    let a = "1L,"
    a = a.repeat(list_length - 1)+'1L'
    let b = "{\"#c\":\"ae2:i\",id:\"expatternprovider:infinity_cell\",tag:{record:{\"#c\":\"ae2:"+type+"\",id:\""+list[0]+"\"}}}"
    for(let i = 1;i < list_length;i++)
    {
        b = b + ",{\"#c\":\"ae2:i\",id:\"expatternprovider:infinity_cell\",tag:{record:{\"#c\":\"ae2:"+type+"\",id:\""+list[i]+"\"}}}"
    }
    return Item.of('ae2:portable_item_cell_16k',
    "{RepairCost:0,amts:[L;"+a+"],display:{Name:'{\"text\":\""+cellname+"\"}'},ic:"+list_length+"L,internalCurrentPower:20000.0d,keys:["+b+"]}") 
    }
	event.add(packed_infinity_cell_1('脆弱工具元件包','i',['fragile_tool:fragile_file', 'fragile_tool:fragile_hammer', 'fragile_tool:fragile_mallet', 'fragile_tool:fragile_wrench', 'fragile_tool:fragile_wire_cutter', 'fragile_tool:fragile_crowbar', 'fragile_tool:fragile_saw', 'fragile_tool:fragile_screwdriver']))
})