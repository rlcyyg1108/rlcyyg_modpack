ServerEvents.recipes(event => {
    event.shaped("gtceu:stone_rod", [
		'D  ',
		' W ',
		'   '
	], {
		D: 'fragile_tool:fragile_file',
		W: 'minecraft:cobblestone'
    })
    event.shaped('fragile_tool:fragile_hammer', [
		'WWW',
		'WWW',
		' D '
	], {
		D: 'gtceu:stone_rod',
		W: 'minecraft:cobblestone'
    })
    event.shaped('fragile_tool:fragile_wrench', [
		'DWD',
		' D ',
		' D '
	], {
		W: 'fragile_tool:fragile_hammer',
		D: 'minecraft:cobblestone'
    })
    event.shaped('fragile_tool:fragile_saw', [
		'   ',
		'WWD',
		'CHD'
	], {
		D: 'gtceu:stone_rod',
		W: 'minecraft:cobblestone',
        C:'fragile_tool:fragile_file',
        H:'fragile_tool:fragile_hammer'
    })
    event.shaped('fragile_tool:fragile_file', [
		' W ',
		' W ',
		' D '
	], {
		D: 'gtceu:stone_rod',
		W: 'minecraft:cobblestone'
    })
    event.shaped('fragile_tool:fragile_screwdriver', [
		' CD',
		' DH',
		'D  '
	], {
		D: 'gtceu:stone_rod',
        C:'fragile_tool:fragile_file',
        H:'fragile_tool:fragile_hammer'
    })
    event.shaped('fragile_tool:fragile_mallet', [
		'WW ',
		'WWD',
		'WW '
	], {
		D: 'gtceu:stone_rod',
		W: 'minecraft:cobblestone'
    })
    event.shaped('fragile_tool:fragile_crowbar', [
		'HWD',
		'WDW',
		'DWC'
	], {
		D: 'gtceu:stone_rod',
		W: 'minecraft:cobblestone',
        C:'fragile_tool:fragile_file',
        H:'fragile_tool:fragile_hammer'
    })
    event.shaped('fragile_tool:fragile_wire_cutter', [
		'WCW',
		'HWL',
		'DDD'
	], {
		D: 'gtceu:stone_rod',
		W: 'minecraft:cobblestone',
        C:'fragile_tool:fragile_file',
        H:'fragile_tool:fragile_hammer',
        L:'fragile_tool:fragile_screwdriver'
    })
    const gtr = event.recipes.gtceu
    const tools = ['crowbar',
                    'hammer',
                    'mallet',
                    'saw',
                    'screwdriver',
                    'wire_cutter',
                    'wrench',
                    'file']
    tools.forEach(i=>{//fragile_tool:fragile_
        gtr.alloy_smelter('fragile_tool:fragile_'+i+'_1')
            .notConsumable('fragile_tool:fragile_'+i)
            .itemInputs('minecraft:iron_ingot')
            .itemOutputs('64x fragile_tool:fragile_'+i)
            .EUt(1)
            .duration(1)
        gtr.extruder('fragile_tool:fragile_'+i+'_2')
            .notConsumable('fragile_tool:fragile_'+i)
            .itemInputs('minecraft:iron_ingot')
            .itemOutputs('64x fragile_tool:fragile_'+i)
            .EUt(1)
            .duration(1)
    })
    const packed_infinity_cell_1 = (cellname,type,list)=>{
    const list_length = list.length
    let a = "1L,"
    a = a.repeat(list_length - 1)+'1L'
    let b = "{\"#c\":\"ae2:i\",id:\"expatternprovider:infinity_cell\",tag:{record:{\"#c\":\"ae2:"+type+"\",id:\""+list[0]+"\"}}}"
    for(let i = 1;i < list_length;i++)
    {
        b = b + ",{\"#c\":\"ae2:i\",id:\"expatternprovider:infinity_cell\",tag:{record:{\"#c\":\"ae2:"+type+"\",id:\""+list[i]+"\"}}}"
    }
    return Item.of('ae2:portable_item_cell_16k',
    "{RepairCost:0,amts:[L;"+a+"],display:{Name:'{\"text\":\""+cellname+"\"}'},ic:"+list_length+"L,internalCurrentPower:20000.0d,keys:["+b+"]}") 
    }
    event.shapeless(packed_infinity_cell_1('脆弱工具元件包','i',['fragile_tool:fragile_file', 'fragile_tool:fragile_hammer', 'fragile_tool:fragile_mallet', 'fragile_tool:fragile_wrench', 'fragile_tool:fragile_wire_cutter', 'fragile_tool:fragile_crowbar', 'fragile_tool:fragile_saw', 'fragile_tool:fragile_screwdriver']),
    ['ae2:portable_item_cell_16k','gtceu:polybenzimidazole_mallet','gtceu:neutronium_crowbar',
    'gtceu:neutronium_hammer','gtceu:neutronium_saw','gtceu:neutronium_screwdriver',
    'gtceu:neutronium_wire_cutter','gtceu:neutronium_wrench','gtceu:neutronium_file'])
    
})